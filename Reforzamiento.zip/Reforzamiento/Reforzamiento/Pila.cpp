#include "Pila.h"
#include <iostream>
using namespace std;

Pila::Pila() {
    cima = -1;
}

bool Pila::Apilar(int elemento) {
    bool res;
    if (cima == MAX - 1) {
        cout << "Desbordamiento de Pila (Overflow)" << endl;
        res = false;
    }
    else {
        cima++;
        pila[cima] = elemento;
        res = true;
    }
    return res;
}

bool Pila::Desapilar() {
    bool res;
    if (cima == -1) {
        cerr << "Se est� intentando quitar un elemento de una pila vac�a (underflow)" << endl;
        res = false;
    }
    else {
        cima--;
        res = true;
    }
    return res;
}

bool Pila::CimaPila(int& elemento) {
    bool res;
    if (PilaVacia()) {
        cerr << "Se est� intentando quitar un elemento de una pila vac�a (underflow)" << endl;
        res = false;
    }
    else {
        elemento = pila[cima];
        res = true;
    }
    return res;
}

void Pila::LimpiarPila() {
    cima = -1;
}

void Pila::VerPila() {
    for (int i = 0; i <= cima; i++) {
        cout << pila[i] << endl;
    }
}

bool Pila::PilaVacia() {
    return cima == -1;
}

bool Pila::Iguales(Pila p) {
    bool iguales = true;
    if (cima != p.cima) {
        iguales = false;
    }
    else {
        for (int i = 0; i <= cima; i++) {
            if (pila[i] != p.pila[i]) {
                iguales = false;
                break;
            }
        }
    }
    return iguales;
}
